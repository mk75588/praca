package fundusze;

import java.math.BigDecimal;
import java.util.List;

class Zlecenie {

    Rejestr otworzRejestr(Uczestnik uczestnik, Integer nrFunduszu) {
        String rejestrid = generateRejestrId(uczestnik, nrFunduszu);
        Rejestr rejestr = new Rejestr(rejestrid, nrFunduszu, uczestnik.getUczestnikId(), Status.WPROWADZONY);
        System.out.println("Otworzono nowy rejestr o id " + rejestrid);
        uczestnik.getRejestr().add(rejestr);
        return rejestr;
    }

    BigDecimal zamknacRejestr(List<Rejestr> rejestry, String rejestrId) {
        for (Rejestr r : rejestry) {
            if (r.getRejestrid().equalsIgnoreCase(rejestrId)) {
                r.setStatus(Status.ZAMKNIETY);
                r.setStan(BigDecimal.ZERO);
                System.out.println("Rejestr:" + r.getRejestrid() + " został zamknięty");
                return r.getStan();
            }
        }
        return BigDecimal.ZERO;
    }

    void nabycie(List<Rejestr> rejestry, String rejestrId, BigDecimal kwota) {
        for (Rejestr r : rejestry) {
            if (r.getRejestrid().equalsIgnoreCase(rejestrId)) {
                if (r.getStatus().equalsIgnoreCase(Status.WPROWADZONY)) {
                    r.setStatus(Status.AKTYWNY);
                }
                r.setStan(r.getStan().add(kwota));
                System.out.println("Zaksiegowano zlecenie nabycia na kwotę " + kwota);

            }
        }
    }

    void odkupienie(List<Rejestr> rejestrs, String rejestrId, BigDecimal kwota) {
        for (Rejestr r : rejestrs) {
            if (r.getRejestrid().equalsIgnoreCase(rejestrId)) {
                if (czyMogeWyplacic(kwota, r)) return;
                r.setStan(r.getStan().subtract(kwota));
                System.out.println("Zaksiegowano zlecenie odkupienia na kwotę " + kwota);
            }
            System.out.println("Nie znaleziono rejestru o podanym identyfikatorze");
        }
    }

    void transfer(List<Rejestr> rejestry, String rejestrZrodlowyId, String rejestrDocelowyId, BigDecimal kwota) {
        Rejestr rejestrZrodlowy = findRejestr(rejestry, rejestrZrodlowyId);
        Rejestr rejestrDocelowy = findRejestr(rejestry, rejestrDocelowyId);
        if (rejestrZrodlowy != null && rejestrDocelowy != null) {
            if (czyMogeWyplacic(kwota, rejestrZrodlowy)) {
                if (czyStatusPoprawny(rejestrDocelowy)) {
                    System.out.println("Przeniesiono środki z " + rejestrZrodlowyId + " do " + rejestrDocelowyId + " o wartości " + kwota);
                    rejestrZrodlowy.wyplata(kwota);
                    rejestrDocelowy.zasilenie(kwota);
                }
            }
        }
    }

    private boolean czyStatusPoprawny(Rejestr rejestrDocelowy) {
        return !rejestrDocelowy.getStatus().equalsIgnoreCase(Status.ZAMKNIETY);
    }

    private Rejestr findRejestr(List<Rejestr> rejestry, String rejestrId) {
        for (Rejestr r : rejestry) {
            if (r.getRejestrid().equalsIgnoreCase(rejestrId)) {
                return r;
            }
        }
        return null;
    }

    private boolean czyMogeWyplacic(BigDecimal kwota, Rejestr r) {
        if (r.getStan().compareTo(kwota) > -1) {
            System.out.println("Brak wystarczającej kwoty na rejestrze");
            return true;
        }
        return false;
    }

    private String generateRejestrId(Uczestnik uczestnik, Integer nrFunduszu) {
        String nrUczestnika = uczestnik.getUczestnikId().toString();
        int numerRejestru = uczestnik.getRejestr().size();
        return ++numerRejestru + "-" + nrUczestnika + "-" + nrFunduszu;
    }
}
