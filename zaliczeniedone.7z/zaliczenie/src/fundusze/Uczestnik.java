package fundusze;

import java.util.ArrayList;
import java.util.List;

public class Uczestnik {

    private Integer uczestnikId;

    private String imie;

    private String nazwisko;

    private String email;

    private List<Rejestr> rejestr = new ArrayList<>();

    public Uczestnik(Integer uczestnikId, String imie, String nazwisko, String email) {
        this.uczestnikId = uczestnikId;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.email = email;
    }

    public Integer getUczestnikId() {
        return uczestnikId;
    }

    public List<Rejestr> getRejestr() {
        return rejestr;
    }
}
