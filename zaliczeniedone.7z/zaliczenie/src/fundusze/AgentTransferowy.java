package fundusze;

import java.util.ArrayList;
import java.util.List;

public class AgentTransferowy {

    List<Uczestnik> uczestnicy;
    List<Rejestr> rejestrs;

    AgentTransferowy() {
        this.uczestnicy = new ArrayList<>();
        this.rejestrs = new ArrayList<>();
    }

    void dodajUczestnika(String imie, String nazwisko, String email) {
        int size = uczestnicy.size();
        uczestnicy.add((new Uczestnik(++size, imie, nazwisko, email)));
    }

    public List<Uczestnik> getUczestnicy() {
        return uczestnicy;
    }

    public List<Rejestr> getRejestrs() {
        return rejestrs;
    }
}
