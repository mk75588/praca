package fundusze;

import java.math.BigDecimal;
import java.util.List;

class Start {

    public static void main(String[] args) {

        AgentTransferowy agentTransferowy = new AgentTransferowy();
        agentTransferowy.dodajUczestnika("Artur", "Kaczmarek", "a.kaczmarek@gmail.com");
        agentTransferowy.dodajUczestnika("Monika", "Kowalczyk", "m.kowalczyk@gmail.com");

        Zlecenie zlecenie1 = new Zlecenie();
        Rejestr rejestr = zlecenie1.otworzRejestr(agentTransferowy.getUczestnicy().get(0), 1);
        Rejestr rejestr2 = zlecenie1.otworzRejestr(agentTransferowy.getUczestnicy().get(0), 1);
        Rejestr rejestr3 = zlecenie1.otworzRejestr(agentTransferowy.getUczestnicy().get(1), 1);
        agentTransferowy.getRejestrs().add(rejestr);
        agentTransferowy.getRejestrs().add(rejestr2);
        agentTransferowy.getRejestrs().add(rejestr3);

        Zlecenie zlecenie2 = new Zlecenie();

        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());

        }


        zlecenie2.zamknacRejestr(agentTransferowy.getRejestrs(), "1-2-1");


        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());
        }

        zlecenie2.nabycie(agentTransferowy.getRejestrs(), "2-1-1", new BigDecimal(100));

        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());
        }


        zlecenie2.nabycie(agentTransferowy.getRejestrs(), "2-1-1", new BigDecimal(100));

        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());
        }
        zlecenie2.odkupienie(agentTransferowy.getRejestrs(), "1-1-1", new BigDecimal(100));
        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());
        }

        System.out.println("test");
        zlecenie2.transfer(agentTransferowy.getRejestrs(), "2-1-1", "1-1-1", BigDecimal.valueOf(150));

        for (Rejestr r : agentTransferowy.getRejestrs()) {
            System.out.println(r.toString());
        }

        DataBaseService service = new DataBaseService();
        System.out.println("zapis");
        service.zapiszDoPliku(agentTransferowy.getRejestrs());

        List<Rejestr> rejestrs = service.odczytajZPliku();

        System.out.println("odczyt-");
        for (Rejestr rejestr1 : rejestrs) {
            System.out.println(rejestr1.toString());
        }
    }
}
