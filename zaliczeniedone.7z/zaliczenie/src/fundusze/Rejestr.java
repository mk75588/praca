package fundusze;

import java.io.Serializable;
import java.math.BigDecimal;

public class Rejestr implements Serializable {

    private String rejestrid;
    private Integer fundusz;
    private BigDecimal stan = BigDecimal.ZERO;
    private String Status;
    private Integer uczestnik;

    Rejestr(String rejestrid, Integer nrFunduszu, Integer uczestnikId, String wprowadzony) {
        this.rejestrid = rejestrid;
        this.fundusz = nrFunduszu;
        this.uczestnik = uczestnikId;
        this.Status = wprowadzony;
    }

    public void wyplata(BigDecimal kwota) {
        this.stan = stan.subtract(kwota);
    }

    public void zasilenie(BigDecimal kwota) {
        this.stan = stan.add(kwota);
    }

    public void setStan(BigDecimal stan) {
        this.stan = stan;
    }

    public BigDecimal getStan() {
        return stan;
    }

    public String getRejestrid() {
        return rejestrid;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }


    @Override
    public String toString() {
        return "Rejestr{" +
                "rejestrid='" + rejestrid + '\'' +
                ", fundusz=" + fundusz +
                ", stan=" + stan +
                ", Status='" + Status + '\'' +
                ", uczestnik=" + uczestnik +
                '}';
    }


}
