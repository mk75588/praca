package fundusze;

class Status {


    public static final String AKTYWNY = "AKTYWNY";
    public static final String WPROWADZONY = "WPROWADZONY";
    public static final String ZAMKNIETY = "ZAMKNIETY";

}
