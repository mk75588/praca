package fundusze;

import java.io.*;
import java.util.List;

public class DataBaseService {

    void zapiszDoPliku(List<Rejestr> rejestry) {

        try (FileOutputStream f = new FileOutputStream(new File("myObjects.txt"))) {
            ObjectOutputStream o = new ObjectOutputStream(f);
            o.writeObject(rejestry);
            o.close();
            f.close();

        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("Error initializing stream");
        }
    }

    List<Rejestr> odczytajZPliku() {
        FileInputStream fi = null;
        ObjectInputStream oi = null;
        try {
            fi = new FileInputStream(new File("myObjects.txt"));
            oi = new ObjectInputStream(fi);
            return (List<Rejestr>) oi.readObject();
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fi.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                oi.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

}
